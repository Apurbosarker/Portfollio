// Get elements
const loginModal = document.getElementById("login-modal");
const signupModal = document.getElementById("signup-modal");
const loginBtn = document.getElementById("login-btn");
const signupBtn = document.getElementById("signup-btn");
const userProfile = document.getElementById("user-profile");
const profileUsername = document.getElementById("profile-username");

// Local user data for demo (use a database in real projects)
const users = [];

// Show/Hide Login Modal
function showLogin() {
    loginModal.style.display = "block";
}
function hideLogin() {
    loginModal.style.display = "none";
}

// Show/Hide Signup Modal
function showSignup() {
    signupModal.style.display = "block";
}
function hideSignup() {
    signupModal.style.display = "none";
}

// Signup Form Submission
document.getElementById("signupForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("signup-username").value;
    const password = document.getElementById("signup-password").value;

    if (users.some((user) => user.username === username)) {
        alert("Username already exists!");
    } else {
        users.push({ username, password });
        alert("Signup successful! You can now log in.");
        hideSignup();
    }
});

// Login Form Submission
document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    const user = users.find(
        (user) => user.username === username && user.password === password
    );

    if (user) {
        alert("Login successful!");
        showUserProfile(username);
    } else {
        alert("Invalid credentials!");
    }
});

// Show user profile and update navigation bar
function showUserProfile(username) {
    profileUsername.textContent = username;
    userProfile.style.display = "flex";
    loginBtn.style.display = "none";
    signupBtn.style.display = "none";
    hideLogin();
}

// Logout Functionality
function logout() {
    userProfile.style.display = "none";
    loginBtn.style.display = "inline-block";
    signupBtn.style.display = "inline-block";
    alert("You have logged out!");
}


document.getElementById('contact-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const mobile = document.getElementById('mobile').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !email || !mobile || !message) {
        alert('Please fill out all fields!');
        return;
    }

    alert('Thank you for your message!');
    this.reset();
});
